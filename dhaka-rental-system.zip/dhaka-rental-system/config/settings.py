"""
Configuration settings — loaded from environment variables or .env file
"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings:
    # Server
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", 8000))
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite+aiosqlite:///{BASE_DIR}/rental.db")

    # Telegram
    TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    TELEGRAM_CHAT_ID: str = os.getenv("TELEGRAM_CHAT_ID", "")

    # Facebook (for Playwright session)
    FACEBOOK_EMAIL: str = os.getenv("FACEBOOK_EMAIL", "")
    FACEBOOK_PASSWORD: str = os.getenv("FACEBOOK_PASSWORD", "")

    # Storage
    UPLOAD_DIR: Path = BASE_DIR / "uploads"
    USE_S3: bool = os.getenv("USE_S3", "false").lower() == "true"
    AWS_BUCKET: str = os.getenv("AWS_BUCKET", "")
    AWS_ACCESS_KEY: str = os.getenv("AWS_ACCESS_KEY", "")
    AWS_SECRET_KEY: str = os.getenv("AWS_SECRET_KEY", "")
    AWS_REGION: str = os.getenv("AWS_REGION", "ap-southeast-1")

    # Scheduler
    SCRAPE_INTERVAL_MINUTES: int = int(os.getenv("SCRAPE_INTERVAL_MINUTES", 5))

    # Facebook Groups to monitor
    FACEBOOK_GROUPS: list = [
        "https://www.facebook.com/groups/dhakarentalhome",
        "https://www.facebook.com/groups/rentapartmentdhaka",
        "https://www.facebook.com/groups/dhakabaachelorhome",
        "https://www.facebook.com/groups/dhakaflat",
    ]

    # Websites to monitor
    RENTAL_WEBSITES: list = [
        "https://bikroy.com/en/ads/bangladesh/flats-for-rent",
        "https://bproperty.com/en/rent/",
        "https://lamudi.com.bd/house/rent/",
    ]


settings = Settings()
settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
