"""
FastAPI routes — REST API for the dashboard and user submissions.
"""
import shutil
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from sqlalchemy import select, or_, func, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.db import get_db, Listing, Image, UserSubmission, AlertFilter
from parser.parser import parser
from filters.scoring import compute_priority
from config.settings import settings

router = APIRouter()
logger = logging.getLogger(__name__)


# ── Pydantic schemas ──────────────────────────────────────────────────────────

class ListingOut(BaseModel):
    id: int
    rent: Optional[float]
    location: Optional[str]
    sub_area: Optional[str]
    rooms: Optional[int]
    flat_size: Optional[float]
    gas: Optional[str]
    electricity: Optional[str]
    parking: Optional[bool]
    bachelor_allowed: Optional[bool]
    family_only: Optional[bool]
    phone: Optional[str]
    whatsapp: Optional[str]
    source: str
    url: Optional[str]
    description: Optional[str]
    is_urgent: bool
    is_contacted: bool
    priority_score: float
    notes: Optional[str]
    scraped_at: Optional[datetime]
    images: list = []

    class Config:
        from_attributes = True


class FilterCreate(BaseModel):
    name: str
    locations: Optional[List[str]] = None
    min_rent: Optional[float] = None
    max_rent: Optional[float] = None
    min_rooms: Optional[int] = None
    bachelor_ok: Optional[bool] = None


class NoteUpdate(BaseModel):
    notes: Optional[str] = None
    is_contacted: Optional[bool] = None


# ── Listings ──────────────────────────────────────────────────────────────────

@router.get("/listings", response_model=List[dict])
async def get_listings(
    location: Optional[str] = Query(None),
    min_rent: Optional[float] = Query(None),
    max_rent: Optional[float] = Query(None),
    rooms: Optional[int] = Query(None),
    bachelor: Optional[bool] = Query(None),
    source: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(20, le=100),
    sort: str = Query("priority"),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Listing).options(selectinload(Listing.images))

    if location:
        stmt = stmt.where(Listing.location.ilike(f"%{location}%"))
    if min_rent is not None:
        stmt = stmt.where(Listing.rent >= min_rent)
    if max_rent is not None:
        stmt = stmt.where(Listing.rent <= max_rent)
    if rooms is not None:
        stmt = stmt.where(Listing.rooms == rooms)
    if bachelor is not None:
        stmt = stmt.where(Listing.bachelor_allowed == bachelor)
    if source:
        stmt = stmt.where(Listing.source == source)
    if search:
        stmt = stmt.where(
            or_(
                Listing.description.ilike(f"%{search}%"),
                Listing.location.ilike(f"%{search}%"),
            )
        )

    if sort == "priority":
        stmt = stmt.order_by(desc(Listing.priority_score))
    elif sort == "rent_asc":
        stmt = stmt.order_by(Listing.rent.asc().nullslast())
    elif sort == "rent_desc":
        stmt = stmt.order_by(Listing.rent.desc().nullsfirst())
    elif sort == "newest":
        stmt = stmt.order_by(desc(Listing.scraped_at))

    total_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(total_stmt)).scalar()

    stmt = stmt.offset((page - 1) * limit).limit(limit)
    results = (await db.execute(stmt)).scalars().all()

    listings = []
    for r in results:
        d = {
            "id": r.id,
            "rent": r.rent,
            "location": r.location,
            "rooms": r.rooms,
            "flat_size": r.flat_size,
            "gas": r.gas,
            "electricity": r.electricity,
            "parking": r.parking,
            "bachelor_allowed": r.bachelor_allowed,
            "family_only": r.family_only,
            "phone": r.phone,
            "whatsapp": r.whatsapp,
            "source": r.source,
            "url": r.url,
            "description": r.description,
            "is_urgent": r.is_urgent,
            "is_contacted": r.is_contacted,
            "priority_score": r.priority_score,
            "notes": r.notes,
            "scraped_at": r.scraped_at.isoformat() if r.scraped_at else None,
            "images": [
                {"id": img.id, "path": img.local_path, "url": img.image_url, "tags": img.tags}
                for img in r.images
            ],
        }
        listings.append(d)

    return JSONResponse(content={"listings": listings, "total": total, "page": page, "limit": limit})


@router.get("/listings/{listing_id}")
async def get_listing(listing_id: int, db: AsyncSession = Depends(get_db)):
    stmt = select(Listing).options(selectinload(Listing.images)).where(Listing.id == listing_id)
    result = (await db.execute(stmt)).scalars().first()
    if not result:
        raise HTTPException(status_code=404, detail="Listing not found")
    return result


@router.patch("/listings/{listing_id}")
async def update_listing(listing_id: int, update: NoteUpdate, db: AsyncSession = Depends(get_db)):
    stmt = select(Listing).where(Listing.id == listing_id)
    listing = (await db.execute(stmt)).scalars().first()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found")
    if update.notes is not None:
        listing.notes = update.notes
    if update.is_contacted is not None:
        listing.is_contacted = update.is_contacted
    await db.commit()
    return {"status": "updated"}


@router.delete("/listings/{listing_id}")
async def delete_listing(listing_id: int, db: AsyncSession = Depends(get_db)):
    stmt = select(Listing).where(Listing.id == listing_id)
    listing = (await db.execute(stmt)).scalars().first()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found")
    await db.delete(listing)
    await db.commit()
    return {"status": "deleted"}


# ── User Submissions ──────────────────────────────────────────────────────────

@router.post("/submit")
async def submit_listing(
    request: Request,
    rent: Optional[float] = Form(None),
    location: Optional[str] = Form(None),
    rooms: Optional[int] = Form(None),
    flat_size: Optional[float] = Form(None),
    gas: Optional[str] = Form(None),
    electricity: Optional[str] = Form(None),
    water: Optional[str] = Form(None),
    parking: Optional[bool] = Form(None),
    bachelor_allowed: Optional[bool] = Form(None),
    family_only: Optional[bool] = Form(None),
    phone: Optional[str] = Form(None),
    whatsapp: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    restrictions: Optional[str] = Form(None),
    images: List[UploadFile] = File(default=[]),
    db: AsyncSession = Depends(get_db),
):
    # Build text for parser
    text = f"{description or ''} {location or ''} rent {rent or ''} {phone or ''}"
    parsed = parser.parse(text)

    listing = Listing(
        rent=rent,
        location=location or parsed.location,
        rooms=rooms,
        flat_size=flat_size,
        gas=gas,
        electricity=electricity,
        water=water,
        parking=parking,
        bachelor_allowed=bachelor_allowed,
        family_only=family_only,
        phone=phone or parsed.phone,
        whatsapp=whatsapp or parsed.whatsapp,
        description=description,
        restrictions=restrictions,
        source="user",
        content_hash=parsed.content_hash,
    )
    db.add(listing)
    await db.flush()

    # Save images
    saved_images = []
    if images:
        img_dir = settings.UPLOAD_DIR / str(listing.id)
        img_dir.mkdir(parents=True, exist_ok=True)
        for i, upload in enumerate(images[:10]):
            if upload.content_type not in {"image/jpeg", "image/png", "image/webp"}:
                continue
            ext = upload.filename.rsplit(".", 1)[-1] if "." in upload.filename else "jpg"
            filename = f"{listing.id}_{i}.{ext}"
            dest = img_dir / filename
            with dest.open("wb") as f:
                shutil.copyfileobj(upload.file, f)
            img_record = Image(
                listing_id=listing.id,
                local_path=str(dest.relative_to(settings.UPLOAD_DIR.parent)),
                image_url=None,
            )
            db.add(img_record)
            saved_images.append(str(dest))

    submission = UserSubmission(
        listing_id=listing.id,
        ip_address=request.client.host,
        status="approved",
    )
    db.add(submission)
    listing.priority_score = compute_priority({
        "rent": listing.rent,
        "location": listing.location,
        "phone": listing.phone,
        "images": saved_images,
        "is_urgent": parsed.is_urgent,
        "scraped_at": datetime.utcnow(),
    })

    await db.commit()
    return {"status": "submitted", "listing_id": listing.id}


# ── Stats ─────────────────────────────────────────────────────────────────────

@router.get("/stats")
async def get_stats(db: AsyncSession = Depends(get_db)):
    total = (await db.execute(select(func.count(Listing.id)))).scalar()
    today = datetime.utcnow().date()
    today_count = (await db.execute(
        select(func.count(Listing.id)).where(func.date(Listing.scraped_at) == today)
    )).scalar()
    urgent = (await db.execute(
        select(func.count(Listing.id)).where(Listing.is_urgent == True)
    )).scalar()
    sources = (await db.execute(
        select(Listing.source, func.count(Listing.id)).group_by(Listing.source)
    )).all()

    return {
        "total_listings": total,
        "new_today": today_count,
        "urgent": urgent,
        "by_source": {s: c for s, c in sources},
    }


# ── Filters ───────────────────────────────────────────────────────────────────

@router.get("/filters")
async def get_filters(db: AsyncSession = Depends(get_db)):
    results = (await db.execute(select(AlertFilter))).scalars().all()
    return results


@router.post("/filters")
async def create_filter(data: FilterCreate, db: AsyncSession = Depends(get_db)):
    f = AlertFilter(**data.model_dump())
    db.add(f)
    await db.commit()
    await db.refresh(f)
    return f


@router.delete("/filters/{filter_id}")
async def delete_filter(filter_id: int, db: AsyncSession = Depends(get_db)):
    stmt = select(AlertFilter).where(AlertFilter.id == filter_id)
    f = (await db.execute(stmt)).scalars().first()
    if not f:
        raise HTTPException(404, "Filter not found")
    await db.delete(f)
    await db.commit()
    return {"status": "deleted"}


# ── Manual trigger ────────────────────────────────────────────────────────────

@router.post("/scrape/trigger")
async def trigger_scrape():
    """Manually trigger a scraping cycle (runs in background)."""
    import asyncio
    from scheduler.scheduler import scrape_cycle
    asyncio.create_task(scrape_cycle())
    return {"status": "scraping started"}
