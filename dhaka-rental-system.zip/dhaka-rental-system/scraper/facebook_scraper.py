"""
Facebook scraper — uses Playwright to scrape Facebook Groups and Marketplace
with a persistent logged-in session.

IMPORTANT: Run `python -m playwright install chromium` before first use.
"""
import asyncio
import json
import logging
import os
from pathlib import Path
from datetime import datetime
from typing import AsyncGenerator

from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from parser.parser import parser
from filters.scoring import compute_priority
from config.settings import settings

logger = logging.getLogger(__name__)

SESSION_FILE = Path("config/fb_session.json")


class FacebookScraper:
    def __init__(self):
        self.playwright = None
        self.browser: Browser = None
        self.context: BrowserContext = None
        self.page: Page = None

    async def __aenter__(self):
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        # Load saved session to avoid repeated logins
        if SESSION_FILE.exists():
            storage = json.loads(SESSION_FILE.read_text())
            self.context = await self.browser.new_context(storage_state=storage)
            logger.info("Loaded existing Facebook session")
        else:
            self.context = await self.browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/123.0.0.0 Safari/537.36"
                )
            )
        self.page = await self.context.new_page()
        return self

    async def __aexit__(self, *args):
        if self.context:
            # Save session for reuse
            storage = await self.context.storage_state()
            SESSION_FILE.write_text(json.dumps(storage))
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

    async def login(self):
        """Log in to Facebook if no valid session exists."""
        if not settings.FACEBOOK_EMAIL or not settings.FACEBOOK_PASSWORD:
            logger.warning("Facebook credentials not set. Skipping FB scraping.")
            return False

        await self.page.goto("https://www.facebook.com/login", wait_until="networkidle")
        await asyncio.sleep(2)

        try:
            await self.page.fill("#email", settings.FACEBOOK_EMAIL)
            await self.page.fill("#pass", settings.FACEBOOK_PASSWORD)
            await self.page.click('button[name="login"]')
            await self.page.wait_for_url("https://www.facebook.com/", timeout=15000)
            logger.info("✅ Facebook login successful")
            return True
        except Exception as e:
            logger.error(f"Facebook login failed: {e}")
            return False

    async def check_logged_in(self) -> bool:
        await self.page.goto("https://www.facebook.com/", wait_until="domcontentloaded")
        return "facebook.com/login" not in self.page.url

    async def scrape_group(self, group_url: str) -> AsyncGenerator[dict, None]:
        """Scrape posts from a Facebook Group."""
        logger.info(f"Scraping FB group: {group_url}")
        try:
            await self.page.goto(group_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)

            # Scroll to load more posts
            for _ in range(3):
                await self.page.evaluate("window.scrollBy(0, 2000)")
                await asyncio.sleep(2)

            posts = await self.page.query_selector_all('[data-pagelet^="FeedUnit"]')
            if not posts:
                posts = await self.page.query_selector_all('div[role="article"]')

            logger.info(f"Found {len(posts)} posts in group")

            for post in posts[:20]:  # Process up to 20 newest posts
                try:
                    data = await self._extract_post(post, group_url)
                    if data:
                        yield data
                except Exception as e:
                    logger.debug(f"Post extraction error: {e}")

        except Exception as e:
            logger.error(f"Error scraping group {group_url}: {e}")

    async def scrape_marketplace(self) -> AsyncGenerator[dict, None]:
        """Scrape Facebook Marketplace for Dhaka rentals."""
        url = "https://www.facebook.com/marketplace/dhaka/propertyrentals"
        logger.info(f"Scraping FB Marketplace: {url}")
        try:
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)

            for _ in range(2):
                await self.page.evaluate("window.scrollBy(0, 2000)")
                await asyncio.sleep(2)

            items = await self.page.query_selector_all('div[data-visualcompletion="media-vc-image"]')
            if not items:
                items = await self.page.query_selector_all('div[class*="x1lliihq"]')

            logger.info(f"Found {len(items)} marketplace listings")

            for item in items[:20]:
                try:
                    link = await item.query_selector('a')
                    if not link:
                        continue
                    href = await link.get_attribute("href")
                    if not href:
                        continue
                    full_url = "https://www.facebook.com" + href if href.startswith("/") else href

                    text = await item.inner_text()
                    images_els = await item.query_selector_all("img")
                    images = []
                    for img in images_els:
                        src = await img.get_attribute("src")
                        if src:
                            images.append(src)

                    parsed = parser.parse(text, full_url)
                    data = self._to_dict(parsed, full_url, text, "facebook_marketplace", images)
                    data["priority_score"] = compute_priority(data)
                    yield data

                except Exception as e:
                    logger.debug(f"Marketplace item error: {e}")

        except Exception as e:
            logger.error(f"Marketplace scraping error: {e}")

    async def _extract_post(self, post, group_url: str) -> dict | None:
        try:
            text = await post.inner_text()
            if not text or len(text) < 30:
                return None

            # Filter for rental-related posts
            rental_keywords = ["rent", "ভাড়া", "flat", "room", "apartment", "house", "বাসা", "ফ্ল্যাট"]
            if not any(kw in text.lower() for kw in rental_keywords):
                return None

            # Get post URL
            link_el = await post.query_selector('a[href*="/groups/"]')
            post_url = ""
            if link_el:
                post_url = await link_el.get_attribute("href") or ""
                if post_url.startswith("/"):
                    post_url = "https://www.facebook.com" + post_url

            # Get images
            images = []
            img_els = await post.query_selector_all("img[src]")
            for img in img_els[:5]:
                src = await img.get_attribute("src")
                if src and "scontent" in src:
                    images.append(src)

            parsed = parser.parse(text, post_url)
            data = self._to_dict(parsed, post_url or group_url, text[:1000], "facebook_group", images)
            data["priority_score"] = compute_priority(data)
            return data

        except Exception as e:
            logger.debug(f"Post parse error: {e}")
            return None

    @staticmethod
    def _to_dict(parsed, url, description, source, images):
        return {
            "rent": parsed.rent,
            "location": parsed.location,
            "rooms": parsed.rooms,
            "flat_size": parsed.flat_size,
            "room_size": parsed.room_size,
            "gas": parsed.gas,
            "electricity": parsed.electricity,
            "water": parsed.water,
            "parking": parsed.parking,
            "bachelor_allowed": parsed.bachelor_allowed,
            "family_only": parsed.family_only,
            "gender_restriction": parsed.gender_restriction,
            "has_curfew": parsed.has_curfew,
            "phone": parsed.phone,
            "whatsapp": parsed.whatsapp,
            "source": source,
            "url": url,
            "description": description,
            "content_hash": parsed.content_hash,
            "is_urgent": parsed.is_urgent,
            "images": images,
            "scraped_at": datetime.utcnow(),
        }
