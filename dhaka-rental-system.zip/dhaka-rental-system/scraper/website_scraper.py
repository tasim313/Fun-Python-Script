"""
Website scraper — scrapes Bikroy, BProperty, Lamudi (and any generic HTML page)
using httpx (async) + BeautifulSoup.
"""
import asyncio
import logging
import hashlib
from typing import AsyncGenerator
from datetime import datetime

import httpx
from bs4 import BeautifulSoup

from parser.parser import parser
from filters.scoring import compute_priority

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/123.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

# ── Site-specific extraction rules ────────────────────────────────────────────
SITE_RULES = {
    "bikroy.com": {
        "listing_selector": "li.item",
        "title_selector": "a.item-title",
        "price_selector": "strong.price-value",
        "location_selector": "div.item-location span",
        "link_attr": "href",
        "base_url": "https://bikroy.com",
    },
    "bproperty.com": {
        "listing_selector": "article.listing-item",
        "title_selector": "h2.listing-item__title",
        "price_selector": "span.listing-item__price",
        "location_selector": "span.listing-item__location",
        "link_attr": "a",
        "base_url": "https://bproperty.com",
    },
    "lamudi.com.bd": {
        "listing_selector": "div.listing-card",
        "title_selector": "h2.listing-title",
        "price_selector": "div.listing-price",
        "location_selector": "div.listing-location",
        "link_attr": "a",
        "base_url": "https://lamudi.com.bd",
    },
}


def _get_site_key(url: str) -> str:
    for key in SITE_RULES:
        if key in url:
            return key
    return "generic"


class WebsiteScraper:
    def __init__(self):
        self.client = None

    async def __aenter__(self):
        self.client = httpx.AsyncClient(
            headers=HEADERS,
            timeout=30,
            follow_redirects=True,
        )
        return self

    async def __aexit__(self, *args):
        if self.client:
            await self.client.aclose()

    async def scrape_url(self, url: str) -> AsyncGenerator[dict, None]:
        """Scrape a single listing page URL and yield structured listings."""
        try:
            resp = await self.client.get(url)
            resp.raise_for_status()
        except Exception as e:
            logger.warning(f"Failed to fetch {url}: {e}")
            return

        soup = BeautifulSoup(resp.text, "html.parser")
        site_key = _get_site_key(url)

        if site_key in SITE_RULES:
            async for listing in self._extract_with_rules(soup, SITE_RULES[site_key], url):
                yield listing
        else:
            async for listing in self._generic_extract(soup, url, resp.text):
                yield listing

    async def _extract_with_rules(self, soup, rules: dict, page_url: str) -> AsyncGenerator[dict, None]:
        cards = soup.select(rules["listing_selector"])
        logger.info(f"Found {len(cards)} listings on {page_url}")

        for card in cards:
            try:
                title_el = card.select_one(rules["title_selector"])
                price_el = card.select_one(rules["price_selector"])
                loc_el = card.select_one(rules["location_selector"])
                link_el = card.select_one("a")

                title = title_el.get_text(strip=True) if title_el else ""
                price_text = price_el.get_text(strip=True) if price_el else ""
                location_text = loc_el.get_text(strip=True) if loc_el else ""
                raw_text = card.get_text(separator=" ", strip=True)

                href = link_el.get("href", "") if link_el else ""
                if href and not href.startswith("http"):
                    href = rules["base_url"] + href

                # Parse full text
                parsed = parser.parse(raw_text + " " + price_text, href)
                parsed.location = parsed.location or location_text[:100]

                images = [img["src"] for img in card.select("img") if img.get("src")]

                data = self._to_dict(parsed, href, title, "website", images)
                data["priority_score"] = compute_priority(data)
                yield data

            except Exception as e:
                logger.error(f"Error parsing card: {e}", exc_info=True)

    async def _generic_extract(self, soup, page_url: str, raw_html: str) -> AsyncGenerator[dict, None]:
        """Fallback: treat entire page as one listing."""
        text = soup.get_text(separator=" ", strip=True)
        if not text or len(text) < 50:
            return

        parsed = parser.parse(text, page_url)
        images = [img["src"] for img in soup.select("img") if img.get("src")][:10]

        data = self._to_dict(parsed, page_url, text[:200], "website", images)
        data["priority_score"] = compute_priority(data)
        yield data

    @staticmethod
    def _to_dict(parsed, url, description, source, images):
        return {
            "rent": parsed.rent,
            "location": parsed.location,
            "rooms": parsed.rooms,
            "flat_size": parsed.flat_size,
            "room_size": parsed.room_size,
            "gas": parsed.gas,
            "electricity": parsed.electricity,
            "water": parsed.water,
            "parking": parsed.parking,
            "bachelor_allowed": parsed.bachelor_allowed,
            "family_only": parsed.family_only,
            "gender_restriction": parsed.gender_restriction,
            "has_curfew": parsed.has_curfew,
            "phone": parsed.phone,
            "whatsapp": parsed.whatsapp,
            "source": source,
            "url": url,
            "description": description,
            "content_hash": parsed.content_hash,
            "is_urgent": parsed.is_urgent,
            "images": images,
            "scraped_at": datetime.utcnow(),
        }
