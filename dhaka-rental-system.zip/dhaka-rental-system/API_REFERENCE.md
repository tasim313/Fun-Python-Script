# Dhaka Rental Monitor — Example Output & API Reference

## Example Listing JSON

```json
{
  "id": 42,
  "rent": 18000,
  "location": "Dhanmondi",
  "sub_area": null,
  "rooms": 2,
  "flat_size": 850,
  "room_size": "medium",
  "gas": "included",
  "electricity": "separate",
  "water": "included",
  "parking": false,
  "bachelor_allowed": true,
  "family_only": false,
  "gender_restriction": null,
  "has_curfew": false,
  "restrictions": "No pets",
  "phone": "01711234567",
  "whatsapp": "01711234567",
  "messenger": null,
  "source": "facebook_group",
  "url": "https://www.facebook.com/groups/xxxx/posts/yyyy",
  "description": "2 bedroom flat in Dhanmondi R/A...",
  "is_urgent": false,
  "is_contacted": false,
  "priority_score": 78.5,
  "notes": null,
  "scraped_at": "2024-06-01T10:23:00Z",
  "created_at": "2024-06-01T10:23:00Z",
  "images": [
    {
      "id": 101,
      "listing_id": 42,
      "local_path": "uploads/42/42_abc123.jpg",
      "image_url": "https://scontent.xx.fbcdn.net/...",
      "tags": ["bedroom", "furnished"],
      "room_type": "bedroom",
      "is_furnished": true
    }
  ]
}
```

## Telegram Alert Format

```
🔥 New Rental Found!

📍 Location: Dhanmondi
💰 Rent: 18,000 BDT
🏠 Rooms: 2
⛽ Gas: Included
⚡ Electricity: Separate
🚗 Parking: ❌ No
👤 Bachelor OK: ✅ Yes
📞 Contact: 01711234567
📌 Source: Facebook Group

👉 View Listing: https://facebook.com/...
```

## REST API Endpoints

### Listings

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/listings` | List all listings (filterable) |
| GET | `/api/listings/{id}` | Get single listing with images |
| PATCH | `/api/listings/{id}` | Update notes / contacted status |
| DELETE | `/api/listings/{id}` | Delete a listing |

**Query params for GET /api/listings:**
- `location` — text filter
- `min_rent`, `max_rent` — rent range
- `rooms` — exact room count
- `bachelor` — true/false
- `source` — facebook_group / website / user
- `search` — full-text keyword
- `sort` — priority / newest / rent_asc / rent_desc
- `page`, `limit` — pagination

### Submissions

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/submit` | Submit listing (multipart/form-data) |

**Form fields:**
`rent`, `location`, `rooms`, `flat_size`, `gas`, `electricity`,
`water`, `parking`, `bachelor_allowed`, `family_only`, `phone`,
`whatsapp`, `description`, `restrictions`, `images` (files)

### Filters

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/filters` | List alert filters |
| POST | `/api/filters` | Create alert filter |
| DELETE | `/api/filters/{id}` | Delete alert filter |

### System

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/stats` | Dashboard statistics |
| POST | `/api/scrape/trigger` | Manually trigger scrape cycle |

## Telegram Bot Setup

1. Open Telegram → search **@BotFather**
2. Send `/newbot` and follow prompts
3. Copy the **token** → set `TELEGRAM_BOT_TOKEN` in `.env`
4. Start a chat with your bot or add it to a group
5. Visit `https://api.telegram.org/bot<TOKEN>/getUpdates`
6. Copy the `chat.id` value → set `TELEGRAM_CHAT_ID` in `.env`
7. Restart the server — alerts will fire automatically
