"""
Scheduler — runs all scraping jobs every N minutes using asyncio.
"""
import asyncio
import logging
from datetime import datetime

from config.settings import settings
from scraper.website_scraper import WebsiteScraper
from scraper.facebook_scraper import FacebookScraper
from database.db import AsyncSessionLocal
from database.db import Listing, Image
from image_processor.processor import ImageProcessor
from notifier.telegram import send_bulk_alerts
from sqlalchemy import select

logger = logging.getLogger(__name__)

_running = True


async def _save_listing(session, data: dict) -> tuple[bool, int | None]:
    """
    Save a listing to the database, deduplicating by URL or content hash.
    Returns (is_new, listing_id).
    """
    # Deduplicate
    stmt = select(Listing).where(
        (Listing.url == data.get("url")) | (Listing.content_hash == data.get("content_hash"))
    )
    existing = (await session.execute(stmt)).scalars().first()
    if existing:
        return False, existing.id

    listing = Listing(
        rent=data.get("rent"),
        location=data.get("location"),
        rooms=data.get("rooms"),
        flat_size=data.get("flat_size"),
        room_size=data.get("room_size"),
        gas=data.get("gas"),
        electricity=data.get("electricity"),
        water=data.get("water"),
        parking=data.get("parking"),
        bachelor_allowed=data.get("bachelor_allowed"),
        family_only=data.get("family_only"),
        gender_restriction=data.get("gender_restriction"),
        has_curfew=data.get("has_curfew"),
        phone=data.get("phone"),
        whatsapp=data.get("whatsapp"),
        source=data.get("source", "unknown"),
        url=data.get("url"),
        description=data.get("description"),
        content_hash=data.get("content_hash"),
        is_urgent=data.get("is_urgent", False),
        priority_score=data.get("priority_score", 0),
        scraped_at=data.get("scraped_at", datetime.utcnow()),
    )
    session.add(listing)
    await session.flush()
    return True, listing.id


async def _save_images(session, image_data: list[dict]):
    for img in image_data:
        session.add(Image(**img))


async def run_website_scraping() -> list[dict]:
    """Scrape all configured websites and return new listings."""
    new_listings = []
    async with WebsiteScraper() as scraper:
        async with ImageProcessor() as img_proc:
            async with AsyncSessionLocal() as session:
                for url in settings.RENTAL_WEBSITES:
                    async for data in scraper.scrape_url(url):
                        is_new, listing_id = await _save_listing(session, data)
                        if is_new and listing_id:
                            # Download images
                            image_urls = data.get("images", [])
                            if image_urls:
                                imgs = await img_proc.download_images(image_urls, listing_id)
                                await _save_images(session, imgs)
                            data["id"] = listing_id
                            new_listings.append(data)

                await session.commit()
    logger.info(f"Website scraping done — {len(new_listings)} new listings")
    return new_listings


async def run_facebook_scraping() -> list[dict]:
    """Scrape Facebook groups and Marketplace."""
    new_listings = []

    if not settings.FACEBOOK_EMAIL:
        logger.info("Facebook credentials not set — skipping FB scraping")
        return new_listings

    async with FacebookScraper() as scraper:
        is_logged_in = await scraper.check_logged_in()
        if not is_logged_in:
            logged_in = await scraper.login()
            if not logged_in:
                return new_listings

        async with ImageProcessor() as img_proc:
            async with AsyncSessionLocal() as session:
                # Groups
                for group_url in settings.FACEBOOK_GROUPS:
                    async for data in scraper.scrape_group(group_url):
                        is_new, listing_id = await _save_listing(session, data)
                        if is_new and listing_id:
                            if data.get("images"):
                                imgs = await img_proc.download_images(data["images"], listing_id)
                                await _save_images(session, imgs)
                            data["id"] = listing_id
                            new_listings.append(data)

                # Marketplace
                async for data in scraper.scrape_marketplace():
                    is_new, listing_id = await _save_listing(session, data)
                    if is_new and listing_id:
                        if data.get("images"):
                            imgs = await img_proc.download_images(data["images"], listing_id)
                            await _save_images(session, imgs)
                        data["id"] = listing_id
                        new_listings.append(data)

                await session.commit()

    logger.info(f"Facebook scraping done — {len(new_listings)} new listings")
    return new_listings


async def scrape_cycle():
    """Run one full scraping cycle across all sources."""
    logger.info("🔄 Starting scrape cycle...")
    start = datetime.utcnow()

    website_new = await run_website_scraping()
    facebook_new = await run_facebook_scraping()

    all_new = website_new + facebook_new
    elapsed = (datetime.utcnow() - start).total_seconds()
    logger.info(f"✅ Scrape cycle complete — {len(all_new)} new listings in {elapsed:.1f}s")

    if all_new:
        await send_bulk_alerts(all_new)

    return all_new


async def start_scheduler():
    global _running
    _running = True
    logger.info(f"⏰ Scheduler started — running every {settings.SCRAPE_INTERVAL_MINUTES} min")
    while _running:
        try:
            await scrape_cycle()
        except Exception as e:
            logger.error(f"Scrape cycle error: {e}", exc_info=True)
        await asyncio.sleep(settings.SCRAPE_INTERVAL_MINUTES * 60)


async def stop_scheduler():
    global _running
    _running = False
    logger.info("Scheduler stopped")
