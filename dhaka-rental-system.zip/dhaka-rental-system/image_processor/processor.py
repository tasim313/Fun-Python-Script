"""
Image processor — downloads listing images, optionally tags them via Claude Vision.
"""
import asyncio
import hashlib
import logging
import mimetypes
from pathlib import Path
from datetime import datetime
from typing import Optional

import httpx

from config.settings import settings

logger = logging.getLogger(__name__)

ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp", "image/gif"}

# Optional: tag images using simple heuristics or Claude Vision API
ROOM_KEYWORDS = {
    "bedroom": ["bed", "bedroom", "mattress", "pillow"],
    "kitchen": ["kitchen", "stove", "sink", "cooking"],
    "bathroom": ["bathroom", "toilet", "washroom", "shower"],
    "living_room": ["sofa", "couch", "living", "tv", "television"],
    "balcony": ["balcony", "veranda", "outdoor"],
}


class ImageProcessor:
    def __init__(self):
        self.upload_dir = settings.UPLOAD_DIR
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.client = None

    async def __aenter__(self):
        self.client = httpx.AsyncClient(timeout=20, follow_redirects=True)
        return self

    async def __aexit__(self, *args):
        if self.client:
            await self.client.aclose()

    async def download_images(self, image_urls: list[str], listing_id: int) -> list[dict]:
        """Download up to 10 images for a listing. Returns list of image dicts."""
        results = []
        tasks = [self._download_one(url, listing_id) for url in image_urls[:10]]
        for coro in asyncio.as_completed(tasks):
            result = await coro
            if result:
                results.append(result)
        return results

    async def _download_one(self, url: str, listing_id: int) -> Optional[dict]:
        if not url or not url.startswith("http"):
            return None
        try:
            resp = await self.client.get(url)
            resp.raise_for_status()

            content_type = resp.headers.get("content-type", "image/jpeg").split(";")[0].strip()
            if content_type not in ALLOWED_MIME:
                return None

            ext = mimetypes.guess_extension(content_type) or ".jpg"
            if ext == ".jpe":
                ext = ".jpg"

            # Build filename from URL hash
            url_hash = hashlib.md5(url.encode()).hexdigest()[:12]
            filename = f"{listing_id}_{url_hash}{ext}"
            dest_dir = self.upload_dir / str(listing_id)
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_path = dest_dir / filename

            dest_path.write_bytes(resp.content)
            local_path = str(dest_path.relative_to(settings.UPLOAD_DIR.parent))

            return {
                "listing_id": listing_id,
                "image_url": url,
                "local_path": local_path,
                "tags": None,
            }

        except Exception as e:
            logger.debug(f"Image download failed ({url[:60]}): {e}")
            return None

    @staticmethod
    def tag_image_by_filename(filename: str, description: str = "") -> dict:
        """
        Simple tag heuristics based on description text.
        For real AI tagging, call Claude Vision API here.
        """
        tags = []
        room_type = None
        desc_lower = description.lower()

        for rtype, keywords in ROOM_KEYWORDS.items():
            if any(kw in desc_lower for kw in keywords):
                tags.append(rtype)
                room_type = room_type or rtype

        is_furnished = any(w in desc_lower for w in ["furnished", "furniture", "sofa", "bed", "wardrobe"])

        return {
            "tags": tags,
            "room_type": room_type,
            "is_furnished": is_furnished,
        }
