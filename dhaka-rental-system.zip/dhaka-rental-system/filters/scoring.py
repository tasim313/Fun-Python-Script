"""
Priority scoring — ranks listings so the best ones surface first.
"""
from datetime import datetime, timezone


def compute_priority(listing_data: dict) -> float:
    """
    Score a listing 0–100.
    Higher = better / more urgent to check.
    """
    score = 0.0

    # Newness (max 30 pts) — decay over 24 hours
    scraped_at = listing_data.get("scraped_at") or datetime.now(timezone.utc)
    if isinstance(scraped_at, str):
        scraped_at = datetime.fromisoformat(scraped_at)
    age_hours = (datetime.now(timezone.utc) - scraped_at.replace(tzinfo=timezone.utc)).total_seconds() / 3600
    score += max(0, 30 - age_hours * 1.25)

    # Location match (max 20 pts)
    if listing_data.get("location"):
        score += 20

    # Contact available (max 15 pts)
    if listing_data.get("phone"):
        score += 10
    if listing_data.get("whatsapp"):
        score += 5

    # Urgent keyword (15 pts)
    if listing_data.get("is_urgent"):
        score += 15

    # Rent specified (10 pts)
    if listing_data.get("rent"):
        score += 10

    # Images available (10 pts)
    images = listing_data.get("images", [])
    score += min(10, len(images) * 2.5)

    return round(score, 2)
