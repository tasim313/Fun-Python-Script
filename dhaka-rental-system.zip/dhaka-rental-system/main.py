"""
Dhaka Rental Monitoring System
Main entry point - starts the API server and scheduler
"""
import asyncio
import uvicorn
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from database.db import init_db
from api.routes import router as api_router
from scheduler.scheduler import start_scheduler, stop_scheduler
from config.settings import settings
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("logs/app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    logger.info("🚀 Starting Dhaka Rental Monitoring System...")
    await init_db()
    logger.info("✅ Database initialized")
    scheduler_task = asyncio.create_task(start_scheduler())
    logger.info("✅ Scheduler started")
    yield
    await stop_scheduler()
    scheduler_task.cancel()
    logger.info("🛑 System shutdown complete")


app = FastAPI(
    title="Dhaka Rental Monitor",
    description="Real-time rental intelligence system for Dhaka, Bangladesh",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info",
    )
