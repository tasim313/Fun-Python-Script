"""
NLP Parser — extracts structured rental data from raw Bengali/English text
using regex patterns and keyword matching.
"""
import re
import hashlib
import logging
from typing import Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ── Location keyword map ──────────────────────────────────────────────────────
LOCATION_KEYWORDS = {
    "Bashundhara": ["bashundhara", "bashundara", "bshra"],
    "Uttara": ["uttara", "uttora"],
    "Mirpur": ["mirpur", "mirpor"],
    "Dhanmondi": ["dhanmondi", "dhanmandi", "dmondi"],
    "Gulshan": ["gulshan", "gulsahn"],
    "Banani": ["banani", "bananni"],
    "Mohammadpur": ["mohammadpur", "mohammedpur", "mohammadpore"],
    "Rayer Bazar": ["rayer bazar", "rayerbazar"],
    "Farmgate": ["farmgate", "farm gate"],
    "Motijheel": ["motijheel", "motijhil"],
    "Khilgaon": ["khilgaon", "khilgoan"],
    "Badda": ["badda"],
    "Rampura": ["rampura"],
    "Malibagh": ["malibagh"],
    "Shyamoli": ["shyamoli", "shamoli"],
    "Kalabagan": ["kalabagan", "kala bagan"],
    "Green Road": ["green road", "greenroad"],
    "Siddhirganj": ["siddhirganj", "siddhirgonj"],
    "Demra": ["demra"],
    "Jatrabari": ["jatrabari", "jatra bari"],
    "Wari": ["wari"],
    "Old Dhaka": ["old dhaka", "puran dhaka", "lalbagh"],
    "Tejgaon": ["tejgaon", "tejgoan"],
    "Paltan": ["paltan"],
    "Mogbazar": ["mogbazar", "mag bazar"],
    "Khilkhet": ["khilkhet"],
    "Aftabnagar": ["aftabnagar", "aftab nagar"],
    "Vatara": ["vatara", "bhatara"],
    "Niketan": ["niketan"],
    "Eskaton": ["eskaton", "eskhaton"],
    "Elephantroad": ["elephant road", "elephantroad", "new elephant road"],
    "Shahbag": ["shahbag", "shahbagh"],
    "Hatirpool": ["hatirpool", "hatirpul"],
    "Jigatola": ["jigatola"],
}

# ── Regex patterns ────────────────────────────────────────────────────────────
RENT_PATTERNS = [
    r'(?:rent|ভাড়া|taka|tk|bdt)[:\s]*([0-9,]+)',
    r'([0-9,]+)\s*(?:tk|taka|bdt|টাকা)',
    r'([0-9,]+)\s*(?:per month|/month|মাসে)',
    r'(?:monthly|মাসিক)[:\s]*([0-9,]+)',
    r'\b([0-9]{4,6})\b',
]

PHONE_PATTERNS = [
    r'(?:\+88)?01[3-9]\d{8}',
    r'01[3-9]\d{8}',
    r'\+880\s?1[3-9]\d{8}',
]

ROOM_PATTERNS = [
    r'(\d+)\s*(?:bhk|bedroom|room|কক্ষ|রুম)',
    r'(\d+)\s*(?:bed)',
    r'(?:bed|room)s?\s*[:=]\s*(\d+)',
]

SQFT_PATTERNS = [
    r'(\d+)\s*(?:sqft|sq\.?ft|square feet|বর্গফুট)',
    r'(\d+)\s*(?:sft)',
]


@dataclass
class ParsedListing:
    rent: Optional[float] = None
    location: Optional[str] = None
    sub_area: Optional[str] = None
    rooms: Optional[int] = None
    flat_size: Optional[float] = None
    room_size: Optional[str] = None
    gas: Optional[str] = None
    electricity: Optional[str] = None
    water: Optional[str] = None
    parking: Optional[bool] = None
    bachelor_allowed: Optional[bool] = None
    family_only: Optional[bool] = None
    gender_restriction: Optional[str] = None
    has_curfew: Optional[bool] = None
    restrictions: Optional[str] = None
    phone: Optional[str] = None
    whatsapp: Optional[str] = None
    is_urgent: bool = False
    content_hash: str = ""
    raw_phones: list = field(default_factory=list)


class RentalParser:
    def parse(self, text: str, url: str = "") -> ParsedListing:
        if not text:
            return ParsedListing()

        text_lower = text.lower()
        result = ParsedListing()
        result.content_hash = self._hash(text + url)

        result.rent = self._extract_rent(text_lower)
        result.rooms = self._extract_rooms(text_lower)
        result.flat_size = self._extract_sqft(text_lower)
        result.location = self._extract_location(text_lower)
        phones = self._extract_phones(text)
        result.raw_phones = phones
        result.phone = phones[0] if phones else None
        result.whatsapp = self._extract_whatsapp(text_lower, phones)
        result.gas = self._extract_utility(text_lower, "gas", "গ্যাস")
        result.electricity = self._extract_electricity(text_lower)
        result.water = self._extract_utility(text_lower, "water", "পানি")
        result.parking = self._has_parking(text_lower)
        result.bachelor_allowed = self._is_bachelor_ok(text_lower)
        result.family_only = self._is_family_only(text_lower)
        result.gender_restriction = self._extract_gender(text_lower)
        result.has_curfew = self._has_curfew(text_lower)
        result.room_size = self._extract_room_size(text_lower)
        result.is_urgent = self._is_urgent(text_lower)

        return result

    # ── Extractors ────────────────────────────────────────────────────────────

    def _extract_rent(self, text: str) -> Optional[float]:
        for pattern in RENT_PATTERNS:
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                raw = m.group(1).replace(",", "")
                try:
                    val = float(raw)
                    if 1000 <= val <= 500000:
                        return val
                except ValueError:
                    continue
        return None

    def _extract_rooms(self, text: str) -> Optional[int]:
        for pattern in ROOM_PATTERNS:
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                try:
                    return int(m.group(1))
                except ValueError:
                    continue
        return None

    def _extract_sqft(self, text: str) -> Optional[float]:
        for pattern in SQFT_PATTERNS:
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                try:
                    return float(m.group(1))
                except ValueError:
                    continue
        return None

    def _extract_location(self, text: str) -> Optional[str]:
        for location, keywords in LOCATION_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    return location
        return None

    def _extract_phones(self, text: str) -> list:
        found = []
        for pattern in PHONE_PATTERNS:
            matches = re.findall(pattern, text)
            for m in matches:
                clean = re.sub(r'[\s\-]', '', m)
                if clean not in found:
                    found.append(clean)
        return found

    def _extract_whatsapp(self, text: str, phones: list) -> Optional[str]:
        m = re.search(r'whatsapp[:\s]*(\+?[0-9\s\-]{10,15})', text, re.IGNORECASE)
        if m:
            return re.sub(r'[\s\-]', '', m.group(1))
        if "whatsapp" in text and phones:
            return phones[0]
        return None

    def _extract_utility(self, text: str, en_word: str, bn_word: str) -> Optional[str]:
        patterns = [
            (rf'{en_word}[:\s]*(included|include|yes|আছে)', "included"),
            (rf'{en_word}[:\s]*(separate|আলাদা|extra)', "separate"),
            (rf'no\s+{en_word}|{en_word}\s+no|নেই', "no"),
            (rf'{en_word}', "yes"),
            (rf'{bn_word}', "yes"),
        ]
        for pattern, value in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return value
        return None

    def _extract_electricity(self, text: str) -> Optional[str]:
        if re.search(r'electricity[:\s]*(included|include)', text, re.IGNORECASE):
            return "included"
        if re.search(r'electricity[:\s]*(separate|extra)', text, re.IGNORECASE):
            return "separate"
        if "electricity" in text or "বিদ্যুৎ" in text:
            return "yes"
        return None

    def _has_parking(self, text: str) -> Optional[bool]:
        if re.search(r'parking\s*(available|yes|আছে)', text, re.IGNORECASE):
            return True
        if re.search(r'no\s*parking|parking\s*(no|নেই)', text, re.IGNORECASE):
            return False
        if "parking" in text:
            return True
        return None

    def _is_bachelor_ok(self, text: str) -> Optional[bool]:
        if re.search(r'bachelor\s*(allowed|ok|welcome|accepted)', text, re.IGNORECASE):
            return True
        if re.search(r'no\s*bachelor|bachelor\s*(not allowed|prohibited)', text, re.IGNORECASE):
            return False
        if "bachelor" in text:
            return True
        return None

    def _is_family_only(self, text: str) -> Optional[bool]:
        if re.search(r'family\s*(only|preferred|wanted)', text, re.IGNORECASE):
            return True
        return False

    def _extract_gender(self, text: str) -> Optional[str]:
        if re.search(r'female\s*(only|preferred)|only\s*female|ladies', text, re.IGNORECASE):
            return "female_only"
        if re.search(r'male\s*(only|preferred)|only\s*male|gents', text, re.IGNORECASE):
            return "male_only"
        return None

    def _has_curfew(self, text: str) -> Optional[bool]:
        if re.search(r'curfew|gate.*close|night.*lock|lock.*night|প্রবেশ', text, re.IGNORECASE):
            return True
        return False

    def _extract_room_size(self, text: str) -> Optional[str]:
        if re.search(r'\b(large|spacious|big)\b', text):
            return "large"
        if re.search(r'\b(small|tiny)\b', text):
            return "small"
        if re.search(r'\bmedium\b', text):
            return "medium"
        return None

    def _is_urgent(self, text: str) -> bool:
        return bool(re.search(r'urgent|asap|immediately|এখনই|জরুরী', text, re.IGNORECASE))

    def _hash(self, text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()


parser = RentalParser()
