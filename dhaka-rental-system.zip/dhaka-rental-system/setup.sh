#!/usr/bin/env bash
# ─────────────────────────────────────────────────────
#  Dhaka Rental Monitor — One-command setup & run
# ─────────────────────────────────────────────────────
set -e

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   DHAKA RENTAL MONITOR — Setup Script    ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# 1. Create virtual environment
if [ ! -d "venv" ]; then
  echo "→ Creating virtual environment..."
  python3 -m venv venv
fi

source venv/bin/activate

# 2. Install dependencies
echo "→ Installing Python dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

# 3. Install Playwright browser
echo "→ Installing Playwright Chromium..."
python -m playwright install chromium

# 4. Set up .env if missing
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo ""
  echo "⚠️  .env file created from template."
  echo "    Edit .env and add your Telegram bot token + Facebook credentials."
  echo ""
fi

# 5. Create directories
mkdir -p uploads logs config

echo ""
echo "✅ Setup complete!"
echo ""
echo "▶  To start the server:"
echo "   source venv/bin/activate && python main.py"
echo ""
echo "▶  Dashboard: http://localhost:8000"
echo "▶  API docs:  http://localhost:8000/docs"
echo ""
