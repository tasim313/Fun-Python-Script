"""
Telegram notifier — sends instant alerts for new listings.

Setup:
1. Create a bot via @BotFather on Telegram
2. Get the bot token
3. Start a chat with your bot (or add to group)
4. Get your chat ID from https://api.telegram.org/bot<TOKEN>/getUpdates
5. Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env
"""
import logging
import asyncio
from typing import Optional

import httpx

from config.settings import settings

logger = logging.getLogger(__name__)

TELEGRAM_API = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}"


def _format_message(listing: dict) -> str:
    rent = f"{int(listing['rent']):,} BDT" if listing.get("rent") else "N/A"
    location = listing.get("location") or "Unknown"
    rooms = str(listing.get("rooms", "N/A"))
    gas = (listing.get("gas") or "N/A").title()
    electricity = (listing.get("electricity") or "N/A").title()
    parking = "✅ Yes" if listing.get("parking") else ("❌ No" if listing.get("parking") is False else "N/A")
    phone = listing.get("phone") or listing.get("whatsapp") or "N/A"
    source = listing.get("source", "unknown").replace("_", " ").title()
    url = listing.get("url", "")
    is_urgent = "🚨 URGENT " if listing.get("is_urgent") else ""
    bachelor = "✅ Yes" if listing.get("bachelor_allowed") else ("❌ No" if listing.get("bachelor_allowed") is False else "N/A")

    msg = (
        f"{is_urgent}🔥 *New Rental Found!*\n\n"
        f"📍 *Location:* {location}\n"
        f"💰 *Rent:* {rent}\n"
        f"🏠 *Rooms:* {rooms}\n"
        f"⛽ *Gas:* {gas}\n"
        f"⚡ *Electricity:* {electricity}\n"
        f"🚗 *Parking:* {parking}\n"
        f"👤 *Bachelor OK:* {bachelor}\n"
        f"📞 *Contact:* `{phone}`\n"
        f"📌 *Source:* {source}\n"
    )
    if url:
        msg += f"\n👉 [View Listing]({url})"

    return msg


async def send_telegram_alert(listing: dict, image_url: Optional[str] = None):
    """Send a formatted alert to the configured Telegram chat."""
    if not settings.TELEGRAM_BOT_TOKEN or not settings.TELEGRAM_CHAT_ID:
        logger.debug("Telegram not configured — skipping notification")
        return

    message = _format_message(listing)

    async with httpx.AsyncClient(timeout=15) as client:
        try:
            if image_url:
                # Send photo with caption
                resp = await client.post(
                    f"{TELEGRAM_API}/sendPhoto",
                    json={
                        "chat_id": settings.TELEGRAM_CHAT_ID,
                        "photo": image_url,
                        "caption": message,
                        "parse_mode": "Markdown",
                    },
                )
            else:
                resp = await client.post(
                    f"{TELEGRAM_API}/sendMessage",
                    json={
                        "chat_id": settings.TELEGRAM_CHAT_ID,
                        "text": message,
                        "parse_mode": "Markdown",
                        "disable_web_page_preview": False,
                    },
                )
            resp.raise_for_status()
            logger.info(f"✅ Telegram alert sent for listing: {listing.get('location')}")
        except Exception as e:
            logger.error(f"Telegram send failed: {e}")


async def send_bulk_alerts(listings: list[dict]):
    """Send alerts for multiple listings with a small delay between each."""
    for listing in listings:
        images = listing.get("images", [])
        first_image = images[0] if images else None
        await send_telegram_alert(listing, first_image)
        await asyncio.sleep(0.5)  # Respect Telegram rate limits
