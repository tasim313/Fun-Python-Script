# 🏠 Dhaka Rental Monitor

A real-time rental intelligence system for finding rooms, flats, and houses in Dhaka, Bangladesh.

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        DHAKA RENTAL MONITOR                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│   ┌──────────────┐   ┌──────────────┐   ┌──────────────────────┐   │
│   │  SCHEDULER   │   │   SCRAPER    │   │      PARSER          │   │
│   │              │──▶│              │──▶│                      │   │
│   │ Every 5 min  │   │ • Playwright │   │ • Regex NLP          │   │
│   │ asyncio loop │   │   (Facebook) │   │ • Location detect    │   │
│   └──────────────┘   │ • httpx+BS4  │   │ • Phone extract      │   │
│                       │   (Websites) │   │ • Rent normalize     │   │
│                       └──────────────┘   └──────────────────────┘   │
│                                                    │                  │
│   ┌──────────────┐   ┌──────────────┐             ▼                  │
│   │  NOTIFIER    │   │  IMG PROC    │   ┌──────────────────────┐   │
│   │              │   │              │   │     DEDUPLICATOR     │   │
│   │ Telegram Bot │   │ • Download   │   │                      │   │
│   │ Instant alert│   │ • Tag/Label  │   │ • URL match          │   │
│   └──────────────┘   │ • Store path │   │ • Content hash       │   │
│          ▲            └──────────────┘   └──────────────────────┘   │
│          │                    │                    │                  │
│          │                    ▼                    ▼                  │
│   ┌──────┴──────────────────────────────────────────────────────┐   │
│   │                      DATABASE (SQLite / PostgreSQL)          │   │
│   │   listings | images | user_submissions | alert_filters       │   │
│   └────────────────────────────────────────────────┬────────────┘   │
│                                                     │                 │
│   ┌─────────────────────────────────────────────────▼────────────┐  │
│   │                      FASTAPI REST API                         │  │
│   │   GET /api/listings   POST /api/submit   GET /api/stats       │  │
│   └──────────────────────────────────────────────────────────────┘  │
│                                 │                                     │
│   ┌─────────────────────────────▼────────────────────────────────┐  │
│   │                    WEB DASHBOARD (HTML/JS)                    │  │
│   │   • Listings table with filters & search                      │  │
│   │   • Image gallery per listing                                 │  │
│   │   • User submission form with image upload                    │  │
│   │   • Alert filter management                                   │  │
│   └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📁 Project Structure

```
dhaka-rental-system/
├── main.py                    # FastAPI app entry point, lifespan events
├── requirements.txt
├── setup.sh                   # One-command install script
├── .env.example               # Config template
├── API_REFERENCE.md
│
├── config/
│   └── settings.py            # All env-var settings
│
├── database/
│   └── db.py                  # SQLAlchemy models: Listing, Image, UserSubmission, AlertFilter
│
├── scraper/
│   ├── website_scraper.py     # httpx + BeautifulSoup scraper for Bikroy, BProperty, Lamudi
│   └── facebook_scraper.py    # Playwright scraper for FB Groups + Marketplace
│
├── parser/
│   └── parser.py              # NLP regex parser — extracts rent, location, phone, rules
│
├── image_processor/
│   └── processor.py           # Async image downloader + tag heuristics
│
├── filters/
│   └── scoring.py             # Priority scoring algorithm (0–100)
│
├── notifier/
│   └── telegram.py            # Telegram Bot API alerts with image preview
│
├── scheduler/
│   └── scheduler.py           # asyncio scheduler — runs all scrapers every N minutes
│
├── api/
│   └── routes.py              # All REST API routes (listings, submit, filters, stats)
│
├── frontend/
│   └── index.html             # Full dashboard — dark UI, filters, gallery, forms
│
├── uploads/                   # Downloaded listing images stored here
└── logs/
    └── app.log
```

---

## ⚡ Quick Start

### 1. Clone & Setup
```bash
git clone <repo>
cd dhaka-rental-system
chmod +x setup.sh
./setup.sh
```

### 2. Configure
```bash
cp .env.example .env
nano .env   # Add Telegram token, Facebook credentials
```

### 3. Run
```bash
source venv/bin/activate
python main.py
```

Dashboard → http://localhost:8000  
API Docs  → http://localhost:8000/docs

---

## 🔧 Manual Installation (step by step)

```bash
# Python 3.11+ required
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
python -m playwright install chromium

mkdir -p uploads logs config
cp .env.example .env
# Edit .env with your credentials

python main.py
```

---

## 🤖 Telegram Bot Setup

1. Open Telegram → message **@BotFather**
2. `/newbot` → follow prompts → copy **token**
3. Set `TELEGRAM_BOT_TOKEN=<token>` in `.env`
4. Start a chat with your new bot
5. Visit `https://api.telegram.org/bot<TOKEN>/getUpdates`
6. Find `"chat":{"id": XXXXXXX}` → set `TELEGRAM_CHAT_ID=XXXXXXX`
7. Restart server → alerts will fire for every new listing

---

## 🌐 Adding New Sources

To add a new website scraper, add an entry to `SITE_RULES` in `scraper/website_scraper.py`:

```python
"example.com": {
    "listing_selector": "div.listing-card",
    "title_selector": "h2.title",
    "price_selector": "span.price",
    "location_selector": "span.location",
    "link_attr": "a",
    "base_url": "https://example.com",
},
```

Then add the URL to `RENTAL_WEBSITES` in `config/settings.py`.

---

## 🐳 Docker (optional)

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt && python -m playwright install chromium --with-deps
COPY . .
EXPOSE 8000
CMD ["python", "main.py"]
```

```bash
docker build -t dhaka-rental .
docker run -p 8000:8000 --env-file .env dhaka-rental
```

---

## 📊 Priority Scoring

Listings are scored 0–100 based on:

| Factor | Points |
|--------|--------|
| Recency (max, decays over 24h) | 30 |
| Location extracted | 20 |
| Phone number found | 10 |
| WhatsApp number found | 5 |
| "Urgent" keyword | 15 |
| Rent specified | 10 |
| Images available | up to 10 |

---

## 🔒 Security Notes

- Facebook session is saved to `config/fb_session.json` — keep this file private
- Never commit `.env` to version control
- Set `DEBUG=false` in production
- For production deployment, use PostgreSQL instead of SQLite
