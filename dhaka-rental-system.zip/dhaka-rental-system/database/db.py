"""
Database models and initialization using SQLAlchemy async + aiosqlite
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, Boolean, Text, DateTime,
    ForeignKey, JSON
)
from sqlalchemy.orm import relationship
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from config.settings import settings

Base = declarative_base()
engine = create_async_engine(settings.DATABASE_URL, echo=False)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Listing(Base):
    __tablename__ = "listings"

    id = Column(Integer, primary_key=True, index=True)
    rent = Column(Float, nullable=True)
    location = Column(String(200), nullable=True)
    sub_area = Column(String(200), nullable=True)
    rooms = Column(Integer, nullable=True)
    flat_size = Column(Float, nullable=True)           # sqft
    room_size = Column(String(50), nullable=True)      # small/medium/large

    # Utilities
    gas = Column(String(50), nullable=True)            # yes/no/included
    electricity = Column(String(50), nullable=True)    # included/separate
    water = Column(String(50), nullable=True)
    parking = Column(Boolean, nullable=True)

    # Rules
    bachelor_allowed = Column(Boolean, nullable=True)
    family_only = Column(Boolean, nullable=True)
    gender_restriction = Column(String(100), nullable=True)
    has_curfew = Column(Boolean, nullable=True)
    restrictions = Column(Text, nullable=True)

    # Contact
    phone = Column(String(50), nullable=True)
    whatsapp = Column(String(50), nullable=True)
    messenger = Column(String(200), nullable=True)

    # Meta
    source = Column(String(100), nullable=False)       # facebook/bikroy/user/etc
    url = Column(String(500), nullable=True, unique=True)
    description = Column(Text, nullable=True)
    content_hash = Column(String(64), nullable=True, unique=True)
    priority_score = Column(Float, default=0.0)
    is_urgent = Column(Boolean, default=False)
    is_contacted = Column(Boolean, default=False)
    notes = Column(Text, nullable=True)

    scraped_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    images = relationship("Image", back_populates="listing", cascade="all, delete-orphan")
    submission = relationship("UserSubmission", back_populates="listing", uselist=False)


class Image(Base):
    __tablename__ = "images"

    id = Column(Integer, primary_key=True, index=True)
    listing_id = Column(Integer, ForeignKey("listings.id", ondelete="CASCADE"))
    image_url = Column(String(500), nullable=True)
    local_path = Column(String(500), nullable=True)
    tags = Column(JSON, nullable=True)           # AI-generated tags
    room_type = Column(String(100), nullable=True)
    cleanliness = Column(String(50), nullable=True)
    is_furnished = Column(Boolean, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    listing = relationship("Listing", back_populates="images")


class UserSubmission(Base):
    __tablename__ = "user_submissions"

    id = Column(Integer, primary_key=True, index=True)
    listing_id = Column(Integer, ForeignKey("listings.id", ondelete="CASCADE"))
    user_id = Column(String(100), nullable=True)
    submitted_at = Column(DateTime, default=datetime.utcnow)
    ip_address = Column(String(50), nullable=True)
    status = Column(String(50), default="pending")   # pending/approved/rejected

    listing = relationship("Listing", back_populates="submission")


class AlertFilter(Base):
    __tablename__ = "alert_filters"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    locations = Column(JSON, nullable=True)          # list of locations
    min_rent = Column(Float, nullable=True)
    max_rent = Column(Float, nullable=True)
    min_rooms = Column(Integer, nullable=True)
    bachelor_ok = Column(Boolean, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db():
    async with AsyncSessionLocal() as session:
        yield session
